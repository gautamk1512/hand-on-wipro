package vinay;

public class assignment02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		int c=a+b;
		System.out.printf("The sum of %d and %d is %d",a,b,c);

	}

}
