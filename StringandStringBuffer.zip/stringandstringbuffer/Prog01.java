package stringandstringbuffer;

import java.util.*;

public class Prog01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        String s = "";
        s = sc.nextLine();

        if (isPalindrome(s))
            System.out.print(s+" is Palindrome!");
        else
            System.out.print(s+" is not Palindrome!");
    }

    static boolean isPalindrome(String s) {
        int l = s.length();
        for (int i = 0; i < l / 2; i++) {
            if (s.charAt(i) != s.charAt(l - i - 1))
                return false;
        }
        return true;
    }
}