package stringandstringbuffer;

import java.util.*;

public class Prog08 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StringBuffer str = new StringBuffer(sc.nextLine());
        int l = str.length();
        boolean valid[] = new boolean[l];

        for(int i=0; i<l; i++)
        	valid[i] = true;

        for(int i=0; i<l; i++) {
            if(str.charAt(i) == '*') {
                valid[i] = false;
                if(i-1 >= 0)
                    valid[i-1] = false;
                if(i+1 < l)
                    valid[i+1] = false;
            }
        }
        
		StringBuffer newStr = new StringBuffer("");
        for(int i=0; i<l; i++) {
            if(valid[i]) {
                newStr.append(str.charAt(i));
            }
        }
        System.out.println(newStr);
	}
}