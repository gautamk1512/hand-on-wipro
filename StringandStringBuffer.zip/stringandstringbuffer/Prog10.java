package stringandstringbuffer;

import java.util.Scanner;

public class Prog10 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String a = sc.nextLine();
		String b = sc.nextLine();
		String bigger = "";
        int l1 = a.length(), l2 = b.length(), l = (l1 < l2)? l1 : l2, i;
        for(i = 0; i < l; i++) {
            bigger += a.charAt(i);
            bigger += b.charAt(i);
        }
        while(i <l1) {
            bigger += a.charAt(i);
            i++;
        }
        while(i <l2) {
            bigger += b.charAt(i);
            i++;
        }
        System.out.println(bigger);
	}
}