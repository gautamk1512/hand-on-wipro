package exceptionHandling;

import java.util.Scanner;

public class Prog01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter an integer: ");
		String stringNum = sc.nextLine();
		try {
			int intNum = Integer.parseInt(stringNum);
			System.out.println("The square is "+ intNum * intNum);
			System.out.println("The work has been done successfully");
		}
		catch(NumberFormatException e) {
			System.out.println("Entered input is not a valid format for an integer.");
		}
	}
}