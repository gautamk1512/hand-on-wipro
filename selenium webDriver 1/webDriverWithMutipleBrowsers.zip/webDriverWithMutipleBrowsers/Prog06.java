package webDriverWithMutipleBrowsers;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Prog06 {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","F:\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://petstore.octoperf.com/");
		driver.findElement(By.xpath("//*[@id=\"Content\"]/p[1]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"MenuContent\"]/a[2]")).click();
		driver.findElement(By.name("username")).sendKeys("j2ee");
		driver.findElement(By.xpath("/html/body/div[2]/div/form/p[2]/input[2]")).clear();
		driver.findElement(By.xpath("/html/body/div[2]/div/form/p[2]/input[2]")).sendKeys("j2ee");
		driver.findElement(By.xpath("/html/body/div[2]/div/form/input")).click();
		driver.findElement(By.linkText("Sign Out")).click();
		driver.close();
	}
}