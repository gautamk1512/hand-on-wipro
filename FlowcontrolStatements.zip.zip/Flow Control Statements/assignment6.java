package vinay;
import java.util.Scanner;
public class assignment6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a String:");
		String s1=sc.nextLine();
		StringBuffer newStr=new StringBuffer(s1);
		for(int i=0;i<s1.length();i++)
		{
			if(Character.isLowerCase(s1.charAt(i)))
			{
				newStr.setCharAt(i,Character.toUpperCase(s1.charAt(i)));
			}
			else if(Character.isUpperCase(s1.charAt(i)))
			{
				newStr.setCharAt(i,Character.toLowerCase(s1.charAt(i)));
			}
		}
		System.out.println(newStr);
		}

	}