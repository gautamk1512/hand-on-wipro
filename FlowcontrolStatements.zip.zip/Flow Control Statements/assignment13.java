package vinay;
public class assignment13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count=0;
		for(int i=10;i<=99;i++)
		{
			for(int j=2;j<i;j++)
			{
				if(i%j==0)
				{
					count=0;
					break;
				}
				else
				{
					count=1;
				}
			}
			if(count==1)
			{
				System.out.println(i);
			}
		}

	}

}
