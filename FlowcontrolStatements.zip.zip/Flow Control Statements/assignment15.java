package vinay;
import java.util.Scanner;
public class assignment15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number: ");
		int n,digit,sum=0;
		n=sc.nextInt();
		while(n>0)
		{
			digit=n%10;
			sum=sum+digit;
			n=n/10;
		}
		System.out.println("The sum of digits is " +sum);
	}

}
