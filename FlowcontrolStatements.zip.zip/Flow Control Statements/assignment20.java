package vinay;

import java.util.Scanner;

public class assignment20 {

    public static void main(String[] args) {
	    // Java Fundamentals
        // Flow Control Statement
        Scanner sc = new Scanner(System.in);

        System.out.println("1. Add\n2. Sub");
        int choice = sc.nextInt();

        int operand1;
        int operand2;
        int result;

        if (choice == 1) {
            System.out.println("Enter first operand: ");
            operand1 = sc.nextInt();
            System.out.println("Enter second operand: ");
            operand2 = sc.nextInt();
            result = operand1 + operand2;
        } else {
            System.out.println("Enter first operand: ");
            operand1 = sc.nextInt();
            System.out.println("Enter second operand: ");
            operand2 = sc.nextInt();
            result = operand1 - operand2;
        }

        System.out.println("Result: " + result);

        System.out.println("Do you want to continue? Y or N");

        sc.nextLine();
        choice = sc.nextLine().charAt(0);

        if (choice == 'Y' || choice == 'y') main(args);

        sc.close();
    }
}
