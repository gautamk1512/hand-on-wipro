package vinay;
import java.util.Objects;
import java.util.Scanner;
public class assignment7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Gender:Male or Female" );
		String Gender=sc.nextLine();
		System.out.println("Enter your age:");
		int age=sc.nextInt();
		if(Objects.equals(Gender, "Male"))
		{
			if(age>=1 && age<=60)
			{
				System.out.println("Interest == 9.2%");
			}
			else
			{
				System.out.println("Interest == 8.3%");
			}
		}
		if(Objects.equals(Gender, "Female"))
		{
			if(age>=1 && age<=58)
			{
				System.out.println("Interest == 8.2%");
			}
			else
			{
				System.out.println("Interest == 7.6%");
			}
		}

	}

}
