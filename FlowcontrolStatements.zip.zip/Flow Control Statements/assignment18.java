package vinay;
import java.util.Scanner;
public class assignment18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number :");
		int n=sc.nextInt();
		int sum=0,temp,rem;
		temp=n;
		while(n>0)
		{
			rem=n%10;
			sum=(sum*10)+rem;
			n=n/10;
		}
		if(temp==sum)
			System.out.println(temp + " is a palindrome");
		else
			System.out.println(temp + " is not a palindrome");
	}

}
