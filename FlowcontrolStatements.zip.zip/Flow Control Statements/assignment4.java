package vinay;
import java.util.Scanner;
public class assignment4 {
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		char x1=sc.next().charAt(0);
		char x2=sc.next().charAt(0);
		if(x1>x2)
		{
			System.out.println(x2 + "," + x1);
		}
		else
		{
			System.out.println(x1 + "," + x2);
		}	
	}
}
