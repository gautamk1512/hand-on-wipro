package vinay;
import java.util.Scanner;
public class assignment12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int temp;
		boolean isPrime=true;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a Number:");
		int a=sc.nextInt();
		sc.close();
		for(int i=2;i<=a/2;i++)
		{
			temp=a%i;
			if(temp==0)
			{
				isPrime=false;
				break;
			}
		}
		if(isPrime)
			System.out.println("Prime Number");
		else
			{
				System.out.println("Not a Prime Number");
			}
		}

}
