package classesandobjects;

public class Patient {
	private String name;
    double height, weight;

    Patient(double h, double w) {
        height = h;
        weight = w;
    }

    double BMI() {
        double bmi = (weight / (height * height) ) * 703;
        return bmi;
    }
}