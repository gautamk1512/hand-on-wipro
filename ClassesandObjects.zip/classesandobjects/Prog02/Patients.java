package classesandobjects;

public class Patients {

	public static void main(String[] args) {
		Patient p = new Patient(66.8, 112.436);
        System.out.println("BMI of Patient is : " + p.BMI());
	}
}