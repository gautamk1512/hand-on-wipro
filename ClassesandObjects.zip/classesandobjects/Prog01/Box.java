package classesandobjects;

public class Box {
	double width, height, depth;
    Box(double w, double h, double d) {
        height = h;
        width = w;
        depth = d;
    }

    public double volume() {
        return width*height*depth;
    }
}