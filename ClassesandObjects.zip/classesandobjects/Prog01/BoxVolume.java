package classesandobjects;

public class BoxVolume {

	public static void main(String[] args) {
		Box b = new Box(10, 20, 30);
        System.out.println("Volume of the box is : " + b.volume());
    }
}