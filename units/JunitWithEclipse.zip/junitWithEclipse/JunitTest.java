package junitWithEclipse;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class JunitTest {
	MyUnit myunit = new MyUnit();
	
	@Test
	public void testStringConcat() {
		assertEquals("tomcat", myunit.stringConcat("tom", "cat"));
	}
}