package testSuite;

import java.util.ArrayList;

public class Employee {
	public String findName(@SuppressWarnings("rawtypes") ArrayList employees,String name) {
		String result = "";
		  if(employees.contains(name)) {
			  result="FOUND";
		  }
		  else{
		   result="NOT FOUND";
		  }
		  return result;
	}	
}