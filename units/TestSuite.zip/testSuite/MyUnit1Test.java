package testSuite;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class MyUnit1Test {
MyUnit1 myunit1 = new MyUnit1();
	
	@Test
	public void testStringConcat() {
		assertEquals("tomcat", myunit1.stringConcat("tom", "cat"));
	}
}