package testSuite;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.Test;

import assertMethodsAndAnnotation.Employee;

public class EmployeeTest {
	Employee e = new Employee();
	ArrayList<String> list = new ArrayList<>();
	{
		list.add("Amit");
		list.add("Sumit");
		list.add("Vaibhav");
	}
	
	@Test
	public void testFindName() {
		System.out.println(list);
		assertEquals("FOUND", e.findName(list, "Amit"));
		System.out.println("tested");
	}
}