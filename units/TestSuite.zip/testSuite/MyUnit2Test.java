package testSuite;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class MyUnit2Test {
MyUnit2 myunit2 = new MyUnit2();
	
	@Test
	public void testPalindromeCheck() {
		assertTrue(myunit2.palindromeCheck("madam"));
		assertTrue(myunit2.palindromeCheck("mom"));
		assertTrue(myunit2.palindromeCheck("dad"));
		assertTrue(myunit2.palindromeCheck("malayalam"));
		assertFalse(myunit2.palindromeCheck("kerala"));
		assertFalse(myunit2.palindromeCheck("india"));
	}
}