package assertMethodsAndAnnotation;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class MyUnitTest {
	MyUnit myunit = new MyUnit();
	
	@Test
	public void testPalindromeCheck() {
		assertTrue(myunit.palindromeCheck("madam"));
		assertTrue(myunit.palindromeCheck("mom"));
		assertTrue(myunit.palindromeCheck("dad"));
		assertTrue(myunit.palindromeCheck("malayalam"));
		assertFalse(myunit.palindromeCheck("kerala"));
		assertFalse(myunit.palindromeCheck("india"));
	}
}