# Employee-Management-System
Employee Management System includes the following tasks:

1). Adding a particular employee details like name ,ID, contact, etc.

2). Searching an employee from the Data in our Files of organisation.

3). Editing the details of the employee like salary, contact no, mail-id etc.

4). Deleting employee details from the Data file.

5). Displaying the working employees associated with an organisation.

The overall working code has been done using collection framework, file operations, looping and switching cases.

Softwares used to execute the code :

1). JDK 1.8.0.73

2). Eclipse IDE Mars.2
