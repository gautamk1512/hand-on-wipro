package vinay;
public class assignment27 {
	
	public static void main(String[] args) {
	int a[]= {12,34,12,45,67,89};
	int temp[]=new int[a.length];
	int x;
	for (int i = 0; i < a.length; i++) {
		for (int j = i + 1; j <a.length; j++) {
			if (a[i] > a[j]) {
				x = a[i];
				a[i] = a[j];
				a[j] = x;
			}
		}
	}
	for(int i=0;i<a.length;i++)
	{
		
		if( a[i]==a[a.length-1] || a[i]!=a[i+1])
		{
			temp[i]=a[i];
		}	
	}
	for(int i=1;i<a.length;i++)
	{
	System.out.print(temp[i]+" ");
	}
}
}