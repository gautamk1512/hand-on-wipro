package vinay;
public class assignment24 {
	public static void main(String[] args) {
		int ascii[] ={48,49,50,51,52,53,54,55,56,57};
		int i=0;
		for(i=0;i<ascii.length;i++)
		{
			System.out.print((char)ascii[i]+" ");
		}
	}

}
