package vinay;
import java.util.Arrays;
public class assignment29 {
	public static void main(String[] args ) {
		int[] arr = {10,20,10,30,40,100,99};
		int element = Integer.MIN_VALUE, max_count=1,count=1;
		Arrays.sort(arr);	
		for (int i=1; i<arr.length; i++)
		{
			if (arr[i] == arr[i-1]) 
			{
				count++;
			}
		    if((arr[i]!=arr[i-1])||(i==arr.length-1))
		    {
		    	if(max_count<count)
		    	{
		    		max_count=count;
		    		element=arr[i-1];
		    	}
		    count=1;
		    }
	    }
	    System.out.println(element++);
}
}