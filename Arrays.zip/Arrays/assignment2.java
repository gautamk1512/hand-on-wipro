package vinay;
import java.util.Arrays;
import java.util.Scanner;

public class assignment22 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of elements you want in array :");
		int n =sc.nextInt();
		int a[]=new int[50];
		System.out.println("Enter all the elements: ");
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}		
		int max = a[0];																	
		for(int i = 1; i < n; i++) {
			if(a[i] > max)
				max = a[i];
		}
		System.out.println("The maximum value of Array is: "+max);
		
		int min = a[0];																	
		for(int i = 1; i < n; i++) {
			if(a[i] < min)
				min = a[i];
		}
		System.out.println("The minimum value of Array is: "+min);
	}

}
