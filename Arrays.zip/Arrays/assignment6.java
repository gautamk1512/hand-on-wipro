package vinay;
import java.util.Scanner;
public class assignment26 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of elements you want in array :");
		int n=sc.nextInt();
		int i;
	    int a[]=new int[50];
	    System.out.println("Enter all the elements: ");
		for(i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}									
		for(i = 0; i < n-1; i++) {
			for(int j = 0; j < n-1; j++) {
				if(a[j] > a[j+1]) {
					int temp = a[j+1];
					a[j+1] = a[j];
					a[j] = temp;
				}
			}
		}
		for(i=0;i<n;i++)
		{
			System.out.print(a[i]+" ");
		}
	}

}

