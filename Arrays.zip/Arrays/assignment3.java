package vinay;
import java.util.Scanner;
public class assignment23 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of elements you want in array :");
		int n=sc.nextInt();
		int i;
		int a[]= new int[50];
		System.out.println("Enter all the elements: ");
		for(i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		int key=sc.nextInt();
		int  flag = 0;
		
		for(i = 0; i < n; i++) {
			if(a[i] == key) {
				flag = 1;
				break;
			}
		}
		if(flag == 1) {
			System.out.println(i);
		}
		else {
			System.out.println("-1");
		}
	}

}
