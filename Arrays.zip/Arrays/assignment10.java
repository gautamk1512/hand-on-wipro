package vinay;
public class assignment30 {
	public static void main(String[] args) {
		if(args.length!=4)
		{
			System.out.println("Please enter 4 integer numbers : ");
		}
		else
		{
			int a[][] = new int[2][2];
			int x=0;	
			for(int i=0; i<a.length;i++)
			{
				for(int j=0; j<a.length;j++)
				{
					a[i][j]=Integer.parseInt(args[x]);
					x++;
				}
			}
			System.out.println("The given array is");
			for(int i=0; i<a.length;i++)
			{
				for(int j=0; j<a.length;j++)
				{
					System.out.print(a[i][j]+"\t");
				}
				System.out.println();
			}
			System.out.println("The reverse of array is ");
			for(int i=a.length-1;i>=0;i--)
			{
				for(int j=a.length-1;j>=0;j--)
				{
					System.out.print(a[i][j]+"\t");
				}
				System.out.println();
			}

		}
	}
}
	