package com.automobile;

import com.vehicle.twowheeler.Hero;
import com.vehicle.twowheeler.Honda;

public class Test {

	public static void main(String[] args) {
		Hero hero = new Hero("Hero Xtreme 160R", "UP78EL4455", "Amit Kumar Sahu", 150);
		System.out.println(hero.getModelName());
		System.out.println(hero.getOwnerName());
		System.out.println(hero.getRegistrationNumber());
		System.out.println(hero.getSpeed()+" kmph");
		hero.radio();
		
		System.out.println();
		
		Honda honda = new Honda("Honda CB Hornet 160R", "UP78FZ5101", "Sumit Kumar Sahu", 110);
		System.out.println(honda.getModelName());
		System.out.println(honda.getOwnerName());
		System.out.println(honda.getRegistrationNumber());
		System.out.println(honda.getSpeed()+" kmph");
		honda.cdplayer();
	}
}