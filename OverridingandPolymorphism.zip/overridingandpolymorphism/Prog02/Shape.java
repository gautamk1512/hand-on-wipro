package overridingandpolymorphism;

public class Shape {
	void draw() {
		System.out.println("Drawing Shape");
	}
	
	void erase() {
		System.out.println("Erasing Shape");
	}
}