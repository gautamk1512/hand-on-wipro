package overridingandpolymorphism;

public class Square extends Shape{
	void draw() {
        System.out.println("Drawing Square");
    }

    void erase() {
        System.out.println("Erasing Square");
    }

	public static void main(String[] args) {
		Shape c = new Circle();
        Shape t = new Triangle();
        Shape s = new Square();

        c.draw(); 
        t.draw(); 
        s.draw();
        System.out.println();
        c.erase();
        t.erase();
        s.erase();
	}
}