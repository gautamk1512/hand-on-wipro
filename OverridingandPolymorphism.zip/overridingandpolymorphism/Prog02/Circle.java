package overridingandpolymorphism;

public class Circle extends Shape{
	void draw() {
        System.out.println("Drawing Circle");
    }

    void erase() {
        System.out.println("Erasing Circle");
    }
}