package overridingandpolymorphism;

public class Triangle extends Shape{
	void draw() {
        System.out.println("Drawing Triangle");
    }

    void erase() {
        System.out.println("Erasing Triangle");
    }
}