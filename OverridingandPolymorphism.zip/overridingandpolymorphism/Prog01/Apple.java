package overridingandpolymorphism;

public class Apple extends Fruit{
	Apple() {
        name = "Apple";
        size = 1;
    }
    void eat() {
        System.out.println(name + " : " + "Sweet");
    }
}