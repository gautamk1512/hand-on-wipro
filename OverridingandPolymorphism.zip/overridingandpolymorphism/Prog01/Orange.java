package overridingandpolymorphism;

public class Orange extends Fruit{
    Orange() {
        name = "Orange";
        size = 2;
    }
    void eat() {
        System.out.println(name + " : " + "Sweet & Sour");
    }

	public static void main(String[] args) {
		Apple apple = new Apple();
        apple.eat();
        Orange orange = new Orange();
        orange.eat();
	}
}