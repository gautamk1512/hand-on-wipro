package inheritance;

public class Teacher extends Person{
	String subject;
    double salary;

    Teacher(String n, String sub, double s) {
        name = n;
        subject = sub;
        salary = s;
    }
    void display() {
        System.out.println("Name : " + name + '\n' + "Subject : " + subject + '\n' + "Salary : " + salary + '\n');
    }
}