package inheritance;

public class Person {
	String name;
}