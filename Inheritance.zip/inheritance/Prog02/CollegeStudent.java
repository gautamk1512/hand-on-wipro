package inheritance;

public class CollegeStudent extends Student{
	int year;
    String major;

    CollegeStudent(String n, int roll, int y, String m) {
        name = n;
        rollno = roll;
        year = y;
        major = m;
    }

    void display() {
        System.out.println("Name : " + name + '\n' + "RollNo : " + rollno + '\n' + "Year : " + year + '\n' + "Major : " + major + '\n');
    }

	public static void main(String[] args) {
		Teacher t = new Teacher("Kameswari", "Computer Science", 1000000);
        CollegeStudent s = new CollegeStudent("Amit", 12, 4, "Electrical Engineering");
        t.display();
        s.display();
	}
}