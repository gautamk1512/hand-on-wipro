package inheritance;

public class Student extends Person {
	int rollno;
}