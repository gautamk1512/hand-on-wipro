package StringBuffer;
import java.util.Scanner;
public class Assignment8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner sc = new Scanner(System.in);
       System.out.println("Enter the string: ");
       String str = sc.nextLine();
       String[] stars = str.split(".[\\*]+.");
       StringBuffer sb = new StringBuffer();
       for(String x:stars)
    	   sb.append(x);
       System.out.println(sb);
	}

}
