package Openart_applicaton;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class TC_01 {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		
		//Set properties of webdriver
		System.setProperty("webdriver.chrome.driver","E:\\chromedriver.exe");
		//create the webdriver instance
		WebDriver dr=new ChromeDriver();
		
		
		//dr.get("https://demo.opencart.com/index.php");
		
		
		
		//OPEN THE SITE
		dr.get("http://localhost/opencart/");
		dr.manage().window().maximize();
		Thread.sleep(4000);
		
		
		//account registration
		dr.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a")).click();
		dr.findElement(By.linkText("Register")).click();
		
		
		dr.findElement(By.xpath("//*[@id=\"input-firstname\"]")).sendKeys("Raki");
		dr.findElement(By.id("input-lastname")).sendKeys("kate");
		dr.findElement(By.id("input-email")).sendKeys("rno@gmail.com");
		dr.findElement(By.id("input-telephone")).sendKeys("8698975621");
		dr.findElement(By.xpath("//*[@id=\"input-password\"]")).sendKeys("rno20");
		dr.findElement(By.xpath("//*[@id=\"input-confirm\"]")).sendKeys("rno20");
		dr.findElement(By.xpath("//*[@id=\"content\"]/form/div/div/input[1]")).click();
		dr.findElement(By.xpath("//*[@id=\"content\"]/form/div/div/input[2]")).click();
		
		//contact us page
		dr.findElement(By.linkText("Contact Us")).click();
		dr.findElement(By.id("input-enquiry")).sendKeys("This is to Change of Address/Phone number");
		dr.findElement(By.xpath("/html/body/div[2]/div/div/form/div/div/input")).click();
		dr.findElement(By.xpath("/html/body/div[2]/div/div/div/div/a")).click();
		
		//samsung galaxy home tab
		dr.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/div[1]/div/div[2]/a/img")).click();
		dr.findElement(By.linkText("Reviews (0)")).click();
		
		/*dr.findElement(By.id("input-review")).sendKeys("<html><head><body><l1>good</l1></body></head></html>");
		dr.findElement(By.xpath("//*[@id=\"form-review\"]/div[4]/div/input[3]")).click();
		dr.findElement(By.id("button-review")).click();*/
		
		//erronius data  taking snapshot
		//dr.findElement(By.id("input-name")).sendKeys("qalitha");
		dr.findElement(By.xpath("//*[@id=\"input-review\"]")).sendKeys("<html>");
		dr.findElement(By.xpath("//*[@id=\"form-review\"]/div[4]/div/input[3]")).click();
		dr.findElement(By.id("button-review")).click();
		File srcScreenshot=dr.findElement(By.xpath("//*[@id=\"form-review\"]/div[2]")).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(srcScreenshot, new File(System.getProperty("user.dir")+"\\ERROROUT.png"));
		Thread.sleep(2000);
		
		
		//correct input
		dr.findElement(By.id("input-name")).sendKeys("alitha");
		dr.findElement(By.id("input-review")).sendKeys("Its a good phone with pretty good features.Good durabilty");
		dr.findElement(By.xpath("/html/body/div[2]/div/div/div/div[1]/div/div[2]/form/div[5]/div/input[3]")).click();
		dr.findElement(By.xpath("//*[@id=\"button-review\"]")).click();
		
		//add to wishlist
		dr.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div[1]/button[1]")).click();
		/*dr.findElement(By.xpath("/html/body/div[2]/div[1]/button")).click();
		((WebElement) dr.findElements(By.id("wishlist-total"))).click();*/
		
		//currency to file
		dr.findElement(By.xpath("//*[@id=\"form-currency\"]/div/button")).click();
		
		//add to cart
		dr.findElement(By.id("button-cart")).click();
		dr.findElement(By.xpath("//*[@id=\"product-product\"]/div[1]/button")).click();
		
		//remove from wishlist 
		dr.findElement(By.id("wishlist-total")).click();
		dr.findElement(By.xpath("//*[@id=\"content\"]/div[1]/table/tbody/tr/td[6]/a")).click();
		dr.findElement(By.xpath("//*[@id=\"account-wishlist\"]/div[1]/button")).click();
		
		//logout
		dr.findElement(By.xpath("//*[@id=\"column-right\"]/div/a[13]")).click();
		/*dr.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a")).click();
		dr.findElement(By.linkText("Logout")).click();*/
		
		
	}

}
