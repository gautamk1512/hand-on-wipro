package Openart_applicaton;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TC_02 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		//Set properties of webdriver
				System.setProperty("webdriver.chrome.driver","E:\\chromedriver.exe");
				//create the webdriver instance
				WebDriver dr=new ChromeDriver();
				
				//OPEN THE SITE
				dr.get("http://localhost/opencart/");
				dr.manage().window().maximize();
				Thread.sleep(4000);
				
				//login button and enter email password
				dr.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a")).click();
				dr.findElement(By.linkText("Login")).click();
				dr.findElement(By.id("input-email")).sendKeys("sos@gmail.com");
				dr.findElement(By.id("input-password")).sendKeys("sos20");
				dr.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div/form/input")).click();
				
				//home
				//dr.findElement(By.xpath("//*[@id=\"account-account\"]/ul/li[1]/a")).click();
				//search
				dr.findElement(By.xpath("/html/body/header/div/div/div[2]/div/input")).sendKeys("apple");
				dr.findElement(By.xpath("//*[@id=\"search\"]/span/button")).click();
				dr.findElement(By.xpath("//*[@id=\"content\"]/div[1]/div[2]/select")).click();
				dr.findElement(By.xpath("//*[@id=\"content\"]/div[1]/div[2]/select/option[10]")).click();
				dr.findElement(By.xpath("//*[@id=\"content\"]/div[1]/div[3]/label/input")).click();
				dr.findElement(By.id("button-search")).click();
				//pda
				
				dr.findElement(By.xpath("/html/body/div[1]/nav/div[2]/ul/li[6]/a")).click();
				dr.findElement(By.id("input-sort")).click();
				dr.findElement(By.xpath("//*[@id=\"input-sort\"]/option[5]")).click();
				
				//add compare
				dr.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div[1]/div/div[2]/div[2]/button[3]")).click();
				dr.findElement(By.xpath("/html/body/div[2]/div[2]/div/div[2]/div[2]/div/div[2]/div[1]/h4/a")).click();
				dr.findElement(By.xpath("/html/body/div[2]/div[2]/div/div[2]/div[3]/div/div[1]/a")).click();
				Thread.sleep(900);
				dr.findElement(By.xpath("/html/body/div[2]/div[2]/div/div[1]/div[2]/div/a")).click();
				
				//first phone information on the page
				dr.findElement(By.xpath("/html/body/div[2]/div/div/div[2]/div[1]/div/div[1]/a")).click();
				String txt=dr.findElement(By.xpath("//*[@id=\"tab-description\"]/ul/li[5]")).getText();
				
				try{
					FileWriter file=new FileWriter("D:\\eclipse\\Final_internship\\src\\Openart_applicaton");
				BufferedWriter bf=new BufferedWriter(file);
				
					bf.write(txt);
					bf.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
	}

}
