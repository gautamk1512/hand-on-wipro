package Openart_applicaton;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TC_08 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","E:\\chromedriver.exe");
		//create the webdriver instance
		WebDriver dr=new ChromeDriver();
		
		//OPEN THE SITE
		dr.get("http://localhost/opencart/");
		dr.manage().window().maximize();
		Thread.sleep(4000);
		
		//login button and enter email password
		dr.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a")).click();
		dr.findElement(By.linkText("Login")).click();
		dr.findElement(By.id("input-email")).sendKeys("sos@gmail.com");
		dr.findElement(By.id("input-password")).sendKeys("sos20");
		dr.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div/form/input")).click();
		
		//go to home page
		dr.findElement(By.xpath("/html/body/div[2]/ul/li[1]/a")).click();
		
		//display a message containing the user link present in the home page
		
		
		//logout
		dr.findElement(By.xpath("//*[@id=\"column-right\"]/div/a[13]")).click();

	}

}
