package Openart_applicaton;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TC_06 {

	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","E:\\chromedriver.exe");
		//create the webdriver instance
		WebDriver dr=new ChromeDriver();
		
		//OPEN THE SITE
		dr.get("http://localhost/opencart/");
		dr.manage().window().maximize();
		Thread.sleep(4000);
		
		//login button and enter email password
		dr.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a")).click();
		dr.findElement(By.linkText("Login")).click();
		dr.findElement(By.id("input-email")).sendKeys("sos@gmail.com");
		dr.findElement(By.id("input-password")).sendKeys("sos20");
		dr.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div/form/input")).click();
		
		//search
		dr.findElement(By.xpath("/html/body/header/div/div/div[2]/div/input")).sendKeys("canon");
		dr.findElement(By.xpath("//*[@id=\"search\"]/span/button")).click();
		dr.findElement(By.xpath("//*[@id=\"content\"]/div[3]/div/div/div[1]/a/img")).click();
		//change the quantity and choose colour
		dr.findElement(By.xpath("//*[@id=\"input-option226\"]")).click();
		dr.findElement(By.xpath("//*[@id=\"input-option226\"]/option[2]")).click();
		
		dr.findElement(By.xpath("//*[@id=\"input-quantity\"]")).sendKeys("2");
		//add to cart
		dr.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div[2]/div[2]/button")).click();
		
		//shoping cart
		dr.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[4]/a")).click();
		//valu of total and place it in the flat file
		String val=dr.findElement(By.xpath("//*[@id=\"content\"]/form/div/table/tbody/tr/td[6]")).getText();
		FileWriter file=new FileWriter("D:\\eclipse\\Final_internship\\src\\Openart_applicaton");
		BufferedWriter bf=new BufferedWriter(file);
		bf.write(val);
		bf.close();
		
		int val1=Integer.parseInt(val);
		if(val1 > 200) {
			dr.findElement(By.xpath("/html/body/div[2]/div[3]/div/div[3]/div[1]/a")).click();
		}
		else {
			dr.findElement(By.xpath("//*[@id=\"column-right\"]/div/a[13]")).click();
		}
		
		
		//display a message containing the user link present in the home page
		
		
		

	}

}
